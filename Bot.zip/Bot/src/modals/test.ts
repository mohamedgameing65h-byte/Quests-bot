import { CommandInteraction } from "discord.js"; // Import CommandInteraction type

export default {
    id: "test",
    function: async function ({ interaction, choices }: { interaction: CommandInteraction, choices: any }) {
        // Your function code here
    }
};
