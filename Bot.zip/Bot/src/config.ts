import { WebhookClient } from "discord.js";
import ms from "ms";
export default {
    // Bot configuration
    token: "----",

    prefix: "-",
    // MongoDB connection URI
    mongoDB: "---",
    // Custom reward images by type key
    rewardImages: {
        "PLACEHOLDER": "https://i.ibb.co/rRNztwKq/reward.webp",
    },
    // Reward types with associated numeric ID
    rewardTypes: {
        5: "Nitro",
        3: "Discord item",
    },
    // Guilds allowed to use the bot
    whiteListedGuildes: ["947363468414160916"],
    // Self account token (used for additional Discord API actions; keep private)
    selfAccountToken: "-------",
    // Available quest types
    quests: [
        "WATCH_VIDEO",
        "PLAY_ON_DESKTOP",
        "STREAM_ON_DESKTOP",
        "PLAY_ACTIVITY",
        "WATCH_VIDEO_ON_MOBILE"
    ],
    // Event types tracked by the bot
    events: [
        "STREAM_ON_DESKTOP",
        "PLAY_ON_DESKTOP",
        "PLAY_ON_PLAYSTATION",
        "PLAY_ON_XBOX",
        "WATCH_VIDEO",
        "WATCH_VIDEO_ON_MOBILE"
    ],
    // Max number of quests a user can take simultaneously
    questsLimit: 15,
    // Minimum duration required to complete a quest
    minQuestTime: ms("30m"),
    // Initial log string on bot start or quest start
    logString: "Developed by PEPO ",
    // Notification settings (e.g. for role pings or logs)
    notification: {
        sendDm: true,
        serverid: "890382499316908033",
        channelid: "890382500881371206",
        role: "1388209268867731516" // Role to mention
    },
    // Server-specific settings related to quest interaction
    server: {
        serverid: "890382499316908033",
        channelid: "890382500881371206",
        roleId: "1388209268867731516",
        logChannel: "890382500881371207",
        // Message shown when a user isn't in the server
        joinMessage: `## انت مو داخل السيرفر
- **عشان تستعمل البوت لازم تدخل السيرفر الحساب الي عايز تعمل فيه المهمة**

## You are not in the server
- **To use the bot, you need to join the server with the account you want to complete the task with.**

- ** https://discord.gg/CRVJ5799yW **`
    },
    // Webhook used for image uploads/logs (move to .env)
    WebhookUrl: new WebhookClient({
        url: process.env.WEBHOOK_URL || "----" // Secure in environment variable
    }),
    // Developer-only access mode
    debugMode: false,
    // Accepted video formats for video quests
    videoFormats: [".mp4", ".mov", ".avi", ".mkv", ".webm"],
    // Developer IDs with full access to bot
    devlopers: [
        "427816027254947840",
        "756947441592303707" // Co-dev/support
    ],
    // Button section shown in bot embeds
    withButtons: {
        active: true,
        buttons: [
            {
                url: "https://www.youtube.com/@PepoSpBlack",
                emoji: "📺",
                text: "قناتي في اليوتيوب"
           }
        ]
    },
};
